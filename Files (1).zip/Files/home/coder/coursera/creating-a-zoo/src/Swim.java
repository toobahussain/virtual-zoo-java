public interface Swim {
    void swimming();
}
