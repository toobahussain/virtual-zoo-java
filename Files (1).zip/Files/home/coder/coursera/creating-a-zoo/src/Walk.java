public interface Walk {
    /** TODO 4: declare a functionality or method named
     *          "walking" with return type "void"
     */
   void walking();
}
